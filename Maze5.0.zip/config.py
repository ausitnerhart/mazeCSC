from random import shuffle, randrange
from itertools import zip_longest

WINDOW_WIDTH = 544
WINDOW_HEIGHT = 544
TILE_SIZE = 32
FIRE_BALL_TILE = 22
FPS = 60
NUM_TROLLS = 1
NUM_MUD = 10
ATTACKS = True

#order in which the stuff gets drawn, player and wall get drawn ontop of grass
CHARACTER_LEVEL = 3
WALL_LEVEL = 2
FLOOR_LEVEL = 1

TROLL_VEL = 2
WITCH_VEL = 2
SKELETON_VEL = 1
GHOST_VEL = 1

DIRECTIONS = ['up', 'down', 'left', 'right']

RED = (255, 0, 0)
BLACK = (0, 0, 0)
BLUE = (0, 0, 255)
WHITE = (255, 255, 255)

def make_maze(w = 5, h = 5):
    vis = [[0] * w + [1] for _ in range(h)] + [[1] * (w + 1)]
    ver = [["W."] * w + ['W'] for _ in range(h)] + [[]]
    hor = [["WW"] * w + ['W'] for _ in range(h + 1)]
 
    def path(x, y):
        vis[y][x] = 1
 
        d = [(x - 1, y), (x, y + 1), (x + 1, y), (x, y - 1)]
        shuffle(d)
        for (xx, yy) in d:
            if vis[yy][xx]: continue
            if xx == x: hor[max(y, yy)][x] = "W."
            if yy == y: ver[y][max(x, xx)] = ".."
            path(xx, yy)
 
    path(randrange(w), randrange(h))

    l = []
    for (a, b) in zip(hor, ver): # creates an iterator from the lists hor and ver that allows each value from both iterators to be assigned to a tuple
        s = ''
        s2 = ''
        for (i, j) in zip_longest(a, b, fillvalue = ''): # uses iterables zip_longest to allow the zip function to create an iterable from the longest iterator rather than the shortest, fills the shorter iterator with blank strings that can be ignored
            s += i
            s2 += j
        l.append(s)
        l.append(s2)
    l.pop()
    return l

MAZE = make_maze()

GUY_SPAWNPOINTS_X = [1, len(MAZE[0]) - 2]
GUY_SPAWNPOINTS_Y = [1, len(MAZE) - 2]