import pygame
from pygame.locals import QUIT
from config import *
from sprites import * 
import sys
from random import *

class Game:
    def __init__(self):
        pygame.init() #initilizes pygame
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT)) #creates screen
        self.clock = pygame.time.Clock() #pygame.clock() sets the framerate
        self.font = pygame.font.Font("arial.ttf", 32) #uses this as font for words
        self.running = True 
        self.lost = False
        self.count = 0
        self.fireball_cooldown = 0
        self.score = 0
        self.high_score = 0
        self.show_flag = 0
        self.skele = 0
        self.level = 1
        self.enemies = []
        self.witch_list = []
        self.skeleton_list = []
        self.alien_list = []
        self.ghost_list = []
        self.iceguy_list = []
        self.boss_list = []
        self.count_freeze = 0
        self.minion_count = 0
        self.guy_speed = 4
        self.trolls_die = False
        self.num_trolls = 0
        self.num_aliens = 0
        self.num_witches = 0
        self.num_iceguys = 0
        self.num_ghosts = 0
        self.num_bosses = 0
        self.attack = True
        self.lose_life = False
        self.lives = 100000000
        
        #imports the spritesheets (this is a temporary thing that we'll change when we get our own images)
        self.character_spritesheet = Spritesheet('img/Male.png')
        self.terrain_spritesheet = Spritesheet('img/terrain.png')
        self.enemy_spritesheet = Spritesheet('img/enemy.png')
        self.intro_background = pygame.image.load("./img/introbackground.png")
        self.flag_spritesheet = Spritesheet('img/flag.png')
        #new ones
        self.attack_spritesheet = Spritesheet('img/attack1.png')
        self.fireball_spritesheet = Spritesheet('img/attack1.png')
        self.witchs_spritesheet = Spritesheet('img/Witch.png')
        self.ghosts_spritesheet = Spritesheet('img/ghost.png')
        self.skeleton_spritesheet = Spritesheet('img/skeleton.png')
        self.blasts_spritesheet = Spritesheet('img/blast.png')
        self.blasts2_spritesheet = Spritesheet('img/blast2.png')
        self.blasts3_spritesheet = Spritesheet('img/blast3.png')
        self.blasts4_spritesheet = Spritesheet('img/blast4.png')
        self.aliens_spritesheet = Spritesheet('img/alian.png')
        self.ice_spritesheet = Spritesheet('img/ice.png')
        self.iceback_spritesheet = Spritesheet('img/icebackground2.png')
        self.heart_spritesheet = Spritesheet('img/heart.png')
        self.blondie_spritesheet = Spritesheet('img/blondie.png')
        self.wizard_unclicked = Spritesheet('img/wizard_unclicked.png')
        self.wizard_clicked = Spritesheet('img/wizard_clicked.png')
        self.blondie_unclicked = Spritesheet('img/blondie_unclicked.png')
        self.blondie_clicked = Spritesheet('img/blondie_clicked.png')
        self.pinky_unclicked = Spritesheet('img/pinky_unclicked.png')
        self.pinky_clicked = Spritesheet('img/pinky_clicked.png')
        self.penny_unclicked = Spritesheet('img/penny_unclicked.png')
        self.penny_clicked = Spritesheet('img/penny_clicked.png')
        
        #boss oness
        self.boss_spritesheet = Spritesheet('img/boss1.png')
        self.minion_spritesheet = Spritesheet('img/minion.png')
        
        #damaged images
        self.damagedcharacter_spritesheet = Spritesheet('img/damaged.png')
        self.damagedboss_spritesheet = Spritesheet('img/damagedboss.png')
        
    def draw_maze(self):
    #evaluates the string MAZE and converts it into the actual GUI
        random_floor_values = [(64,352), (195,352), (600,352), (600,544), (520,544), (600,160), (520,160), (30,160)]
        random_floor = choice(random_floor_values)
        random_wall_values = [(995, 543), (960, 448), (930, 475), (960, 572)]
        random_wall = choice(random_wall_values)
        for x, row in enumerate(MAZE[0]):
            OuterWall(self, x + 8, 7, random_wall[0], random_wall[1])
            OuterWall(self, x + 8, len(MAZE) + 8, random_wall[0], random_wall[1])
        
        for y, row in enumerate(MAZE):
            OuterWall(self, 7, y + 8, random_wall[0], random_wall[1])
            OuterWall(self, len(MAZE[0]) + 8, y + 8, random_wall[0], random_wall[1])
        for y, row in enumerate(MAZE):
            for x, spr in enumerate(row):
                Floor(self, x + 8, y + 8, random_floor[0], random_floor[1])
        for y, row in enumerate(MAZE):
            for x, spr in enumerate(row):
                if (spr == "W"):
                    Wall(self, x + 8, y + 8, random_wall[0], random_wall[1])
        self.generate_mud()
        self.generate_trolls()
        self.generate_guy() #draws the guy
        self.flag = Flag(self, len(MAZE[0]) + 6 + 100, len(MAZE) + 6)
        self.heart1 = Heart(self, 0, 0)
        self.heart2 = Heart(self, 1, 0)
        self.heart3 = Heart(self, 2, 0)
        
        if self.num_bosses > 0:
            self.boss_heart1 = Heart(self, 10, 0)
            self.boss_heart2 = Heart(self, 11, 0)
            self.boss_heart3 = Heart(self, 12, 0)
            self.boss_heart4 = Heart(self, 13, 0)
            self.boss_heart5 = Heart(self, 14, 0)
    
#called whenever we run our game, sets all of our variables for our game
    def new_game(self):
        #starts a new game
        self.show_flag = 0
        self.playing = True
        if self.lost == True:
            self.level = 1
            self.num_trolls = 5
            self.num_aliens = 0
            self.num_witches = 0
            self.num_iceguys = 0
            self.num_ghosts = 0
            self.num_bosses = 0
            self.score = 0
            self.lost = False
        #divides sprites into groups for the programers conveience
        self.all_sprites = pygame.sprite.Group() #Object that contains all the sprites in the game
        #having one group of sprites allows us to update them all at once
        self.move_sprites = pygame.sprite.Group()
        self.walls = pygame.sprite.Group() #walls are stored
        self.outer_walls = pygame.sprite.Group()
        self.trolls = pygame.sprite.Group() #enemies are stored
        self.mud = pygame.sprite.LayeredUpdates() # mud is stored
        self.attacks = pygame.sprite.Group()#attacks sprites are here
        self.fireballs = pygame.sprite.Group() #added fireball
        self.blasts = pygame.sprite.Group()
        self.aliens = pygame.sprite.Group()
        self.flags = pygame.sprite.Group() #flag is stored here
        self.witchs = pygame.sprite.Group() #powerup is stored here
        self.skeleton = pygame.sprite.Group()
        self.ghosts = pygame.sprite.Group()
        self.boss = pygame.sprite.Group()
        self.minion = pygame.sprite.Group()
        self.ice = pygame.sprite.Group()
        self.iceback = pygame.sprite.Group()
        self.hearts = pygame.sprite.Group()
        self.floors = pygame.sprite.Group()
        self.lives = 3
        self.lose_life = False
        
        self.joystickButtonDown = pygame.JOYBUTTONDOWN
        
        #creates a random maze
        global MAZE
        MAZE = make_maze()
        self.draw_maze()
        
    def events(self):
        #allows the user to x out of the game at any time
        for event in pygame.event.get():
            if event.type == QUIT:
                self.playing = False
                self.running = False
             
            if self.attack == True:
                if event.type == self.joystickButtonDown:
                    if event.dict['button'] == 9:
                        if self.guy.facing == "right":
                            fire_x = self.guy.rect.x + 16
                            fire_y = self.guy.rect.y
                        
                        if self.guy.facing == "left":
                            fire_x = self.guy.rect.x - 16
                            fire_y = self.guy.rect.y
                            
                        if self.guy.facing == "up":
                            fire_x = self.guy.rect.x
                            fire_y = self.guy.rect.y - 16
                            
                        if self.guy.facing == "down":
                            fire_x = self.guy.rect.x
                            fire_y = self.guy.rect.y + 16
                        Attack(self, fire_x, fire_y, self.guy.facing)
                        self.attack = False

    
    #runs all of the sprites update functions
    def update(self):
        #updates all the sprites at once
        self.all_sprites.update()
        
        #fireball cooldown
        if self.fireball_cooldown < 1:
            self.fireball_cooldown += 1
        else:
            self.attack = True
            self.fireball_cooldown = 0
        
        #spawns the skeletons
        if self.skele < 300:
            self.skele += 1
        else:
            for witchs in self.witchs:
                Skeleton(self, witchs.rect.x, witchs.rect.y, witchs.facing)
            self.skele = 0
        
        #spawns the blasts for the alien
        if self.count < 60:
            self.count += 1
        else:
            for aliens in self.aliens:
                Blast(self, aliens.rect.x, aliens.rect.y, "right")
                Blast(self, aliens.rect.x, aliens.rect.y, "left")
                Blast(self, aliens.rect.x, aliens.rect.y, "up")
                Blast(self, aliens.rect.x, aliens.rect.y, "down")
            if self.lose_life == True:
                self.lives -= 1
                self.lose_life = False
            self.count = 0
        
        #spawns the fireball for the troll
        if self.count < 60:
            self.count += 1
        
        else:
            for troll in self.trolls:
                 Fireball(self, troll.rect.x, troll.rect.y, troll.facing)
            self.trolls_die = False
            self.count = 0
        
        #spawns the ice for the iceguy
        if self.count_freeze < 240:
            self.count_freeze += 1
        else:
            for ice in self.ice:
                Ice(self, ice.rect.x - 45, ice.rect.y - 40, ice.facing)
            self.count_freeze = 0
        
        #spawns the guys for the boss
        if self.minion_count < 180:
            self.minion_count += 1
        else:
            for boss in self.boss:
                Minion(self, boss.rect.x, boss.rect.y, boss.facing)
                Minion(self, boss.rect.x, boss.rect.y, boss.facing)
            
            for minion in self.minion:
                 Fireball(self, minion.rect.x, minion.rect.y, minion.facing) 
                 
            self.minion_count = 0
        
        if self.lives == 2:
            self.heart3.rect.x = 1000
            
        if self.lives == 1:
            self.heart2.rect.x = 1000
            self.heart3.rect.x = 1000
            
        if self.lives == 0:
            self.heart1.rect.x = 1000
            self.heart2.rect.x = 1000
            self.heart3.rect.x = 1000
            
        if self.num_bosses >= 1:
            if self.boss_list[0].lives == 4:
                self.boss_heart5.rect.x = 1000
            
            if self.boss_list[0].lives == 3:
                self.boss_heart4.rect.x = 1000
                
            if self.boss_list[0].lives == 2:
                self.boss_heart3.rect.x = 1000
                
            if self.boss_list[0].lives == 1:
                self.boss_heart2.rect.x = 1000
                
            if self.boss_list[0].lives == 1:
                self.boss_heart1.rect.x = 1000
            
        if (self.num_bosses == 0 or self.boss_list[0].lives == 0) and (self.show_flag == 0):
            self.flag.rect.x -= TILE_SIZE * 100
            self.show_flag += 1
            self.trolls_die = True
        
            
        
            
       
    def draw(self):
        # draws the board again 60 times a seconds
        self.screen.fill(BLACK)
        self.all_sprites.draw(self.screen) #draws all the sprites
        self.clock.tick(FPS)
        pygame.display.update()
    
    def main(self):
        #every game needs this loop
        #calls every function
        pygame.mixer.music.load('sounds/maze_sound.wav')
        pygame.mixer.music.play(-1)
        while self.playing:
            self.events()
            self.update()
            self.draw()
        self.running = False
    
    def game_over(self):
        if (self.lost == True):
            self.playing = False
            self.running = False
    
    def intro_screen(self):
        intro = True

        title = self.font.render("Awesome Game", True, BLACK)
        title_rect = title.get_rect(x=10, y=10)
        score = self.font.render(f"Score: {self.score}", True, BLACK)
        score_rect = score.get_rect(x = 10, y = 100)
        high_score = self.font.render(f"High Score: {self.high_score}", True, BLACK)
        high_score_rect = high_score.get_rect(x=10, y=140)
        choose = self.font.render(f"Choose your character: ", True, BLACK)
        choose_rect = choose.get_rect(x = 10, y = 180)
        
        play_button = Button(10, 50, 100, 50, WHITE, BLACK, "Play", 32)
        wizard_button = Button(10, 220, 100, 100, WHITE, BLACK, "Wizard", 32)
        blondie_button = Button(120, 220, 100, 100, WHITE, BLACK, "Blondie", 32)
        pinky_button = Button(230, 220, 100, 100, WHITE, BLACK, "Pinky", 32)
        penny_button = Button(340, 220, 100, 100, WHITE, BLACK, "Penny", 32)
        
        wizard_image = self.wizard_unclicked.get_sprite(0, 0, 100, 100)
        blondie_image = self.blondie_unclicked.get_sprite(0, 0, 100, 100)
        pinky_image = self.pinky_unclicked.get_sprite(0, 0, 100, 100)
        penny_image = self.penny_unclicked.get_sprite(0, 0, 100, 100)
        
        while intro:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    intro = False
                    self.running = False
            mouse_pos = pygame.mouse.get_pos()
            mouse_pressed = pygame.mouse.get_pressed()
            
            if play_button.is_pressed(mouse_pos, mouse_pressed):
                intro = False
                
            if wizard_button.is_pressed(mouse_pos, mouse_pressed):
                self.character_spritesheet = Spritesheet('img/Male.png')
                self.damagedcharacter_spritesheet = Spritesheet('img/damaged.png')
                wizard_image = self.wizard_clicked.get_sprite(0, 0, 100, 100)
                blondie_image = self.blondie_unclicked.get_sprite(0, 0, 100, 100)
                penny_image = self.penny_unclicked.get_sprite(0, 0, 100, 100)
                pinky_image = self.pinky_unclicked.get_sprite(0, 0, 100, 100)
                
            if blondie_button.is_pressed(mouse_pos, mouse_pressed):
                self.character_spritesheet = Spritesheet('img/Blondie.png')
                self.damagedcharacter_spritesheet = Spritesheet('img/blondie_damaged.png')
                wizard_image = self.wizard_unclicked.get_sprite(0, 0, 100, 100)
                blondie_image = self.blondie_clicked.get_sprite(0, 0, 100, 100)
                penny_image = self.penny_unclicked.get_sprite(0, 0, 100, 100)
                pinky_image = self.pinky_unclicked.get_sprite(0, 0, 100, 100)
                
            if pinky_button.is_pressed(mouse_pos, mouse_pressed):
                self.character_spritesheet = Spritesheet('img/Pinky.png')
                self.damagedcharacter_spritesheet = Spritesheet('img/pinky_damaged.png')
                wizard_image = self.wizard_unclicked.get_sprite(0, 0, 100, 100)
                blondie_image = self.blondie_unclicked.get_sprite(0, 0, 100, 100)
                pinky_image = self.pinky_clicked.get_sprite(0, 0, 100, 100)
                penny_image = self.penny_unclicked.get_sprite(0, 0, 100, 100)
                
            if penny_button.is_pressed(mouse_pos, mouse_pressed):
                self.character_spritesheet = Spritesheet('img/Penny.png')
                self.damagedcharacter_spritesheet = Spritesheet('img/penny_damaged.png')
                wizard_image = self.wizard_unclicked.get_sprite(0, 0, 100, 100)
                blondie_image = self.blondie_unclicked.get_sprite(0, 0, 100, 100)
                pinky_image = self.pinky_unclicked.get_sprite(0, 0, 100, 100)
                penny_image = self.penny_clicked.get_sprite(0, 0, 100, 100)
                
            self.screen.blit(self.intro_background, (0,0))
            self.screen.blit(title, title_rect)
            self.screen.blit(play_button.image, play_button.rect)
            self.screen.blit(wizard_image, wizard_button.rect)
            self.screen.blit(blondie_image, blondie_button.rect)
            self.screen.blit(pinky_image, pinky_button.rect)
            self.screen.blit(penny_image, penny_button.rect)
            self.screen.blit(high_score, high_score_rect)
            self.screen.blit(score, score_rect)
            self.screen.blit(choose, choose_rect)
           # self.screen.blit(wizard, wizard_rect)
            self.clock.tick(FPS)
            pygame.display.update()
            
    def generate_trolls(self):
        for witch in range(self.num_witches):
            y = randrange(5, len(MAZE) - 5)
            x = randrange(5, len(MAZE[y]) - 5)
            self.witch_list.append(Witch(self, x + 8, y + 8))
        for alien in range(self.num_aliens):
            y = randrange(5, len(MAZE) - 5)
            x = randrange(5, len(MAZE[y]) - 5)
            self.alien_list.append(Alien(self, x + 8, y + 8))
        for ghost in range(self.num_ghosts):
            y = randrange(5, len(MAZE) - 5)
            x = randrange(5, len(MAZE[y]) - 5)
            self.alien_list.append(Ghost(self, x + 8, y + 8))
        for ice in range(self.num_iceguys):
            y = randrange(5, len(MAZE) - 5)
            x = randrange(5, len(MAZE[y]) - 5)
            self.iceguy_list.append(IceGuy(self, x + 8, y + 8))
        for boss in range(self.num_bosses):
            y = randrange(5, len(MAZE) - 5)
            x = randrange(5, len(MAZE[y]) - 5)
            self.boss_list.append(Boss(self, x + 8, y + 8))
        for n in range(self.num_trolls):
            y = randrange(5, len(MAZE) - 5)
            x = randrange(5, len(MAZE[y]) - 5)  
            self.enemies.append(Troll(self, x + 8, y + 8))
                    
    def generate_guy(self):
        x_pos = 1
        y_pos = 1
        self.guy = Guy(self, x_pos + 8, y_pos + 8)
        
    def generate_mud(self):
        for n in range(NUM_MUD):
            positioned = False
            while (positioned == False):
                y = randrange(0, len(MAZE))
                x = randrange(0, len(MAZE[y]))
                if MAZE[y][x] != "W":
                    Mud(self, x + 8, y + 8)
                    positioned = True
        
        
    def new_level(self):
        pygame.mixer.music.stop()
        self.level += 1
        self.score += 1
        if self.score >= self.high_score:
            self.high_score = self.score
        if self.lost == True:
            self.level = 1
            self.score = 0
        self.num_bosses = 0
        #print(SCORE)
        if self.level > 1:
            self.num_trolls += 2
        if self.level % 2 == 0:
            self.num_aliens += 2
        if self.level % 2 == 0:
            self.num_witches += 2
        if self.level % 2 == 0:
            self.num_ghosts += 2
        if self.level % 2 == 0:
            self.num_iceguys += 2
        
        if self.level == 3:
            self.num_bosses += 1
            self.num_trolls = 0
            self.num_aliens = 0
            self.num_witches = 0
            self.num_iceguys = 0
            self.num_ghosts = 0
        if self.num_bosses > 0:
            pygame.mixer.music.load('sounds/boss_sound.wav')
            pygame.mixer.music.play(-1)
            print("boss")
        else:
            pygame.mixer.music.load('sounds/maze_sound.wav')
            pygame.mixer.music.play(-1)
            print("level")
            
        self.enemies = []
        self.witch_list = []
        self.skeleton_list = []
        self.alien_list = []
        self.ghost_list = []
        self.boss_list = []
        self.iceguy_list = []
        self.new_game()
        
    
g = Game()
g.intro_screen()
g.new_game()
while g.running:
    g.main()
    g.game_over()
    
pygame.quit()
sys.exit() 