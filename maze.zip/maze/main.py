import pygame
from pygame.locals import QUIT
from config import *
from sprites import * 
import sys
from random import *

class Game:
    def __init__(self):
        pygame.init()
        self.screen = pygame.display.set_mode((WINDOW_WIDTH, WINDOW_HEIGHT))
        self.clock = pygame.time.Clock()
        # self.font = pygame.font.Font("Arial", 32)
        self.running = True
        self.lost = False
        
        self.character_spritesheet = Spritesheet('img/character.png')
        self.terrain_spritesheet = Spritesheet('img/terrain.png')
        self.enemy_spritesheet = Spritesheet('img/enemy.png')
        
    def draw_maze(self):
        for y, row in enumerate(MAZE):
            for x, spr in enumerate(row):
                Floor(self, x, y)
        for y, row in enumerate(MAZE):
            for x, spr in enumerate(row):
                if (spr == "W"):
                    Wall(self, x, y)
                if (spr == "G"):
                    Guy(self, x, y)
        self.generate_trolls()
        
    def new_game(self):
        #starts a new game
        self.playing = True
        
        self.all_sprites = pygame.sprite.LayeredUpdates()
        self.walls = pygame.sprite.LayeredUpdates()
        self.trolls = pygame.sprite.LayeredUpdates()
        self.attacks = pygame.sprite.LayeredUpdates()
        
        self.generate_maze()
        self.draw_maze()
        
    def events(self):
        for event in pygame.event.get():
            if event.type == QUIT:
                self.playing = False
                self.running = False
        
    def update(self):
        self.all_sprites.update()
       
    def draw(self):
        self.screen.fill(BLACK)
        self.all_sprites.draw(self.screen)
        self.clock.tick(FPS)
        pygame.display.update()
    
    def main(self):
        #main loop
        while self.playing:
            self.events()
            self.update()
            self.draw()
        self.running = False
    
    def game_over(self):
        if (self.lost == True):
            self.playing = False
            self.running = False
    
    def intro_screen(self):
        pass
        
    def generate_maze(self):
        pass
        
    def generate_trolls(self):
        for n in range(NUM_TROLLS):
            positioned = False
            while (positioned == False):
                y = randrange(0, len(MAZE))
                x = randrange(0, len(MAZE[y]))
                if MAZE[y][x] != "W":
                    Troll(self, x, y)
                    positioned = True
        
    
g = Game()
g.intro_screen()
g.new_game()
while g.running:
    g.main()
    g.game_over()
    
pygame.quit()
sys.exit()