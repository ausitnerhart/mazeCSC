import pygame
from config import *
import math
from random import *
import time


class GUI(object):
    def __init__(self, game, x, y):
        self.game = game
        self._level = WALL_LEVEL

        self.x = x * TILE_SIZE
        self.y = y * TILE_SIZE
        self.width = TILE_SIZE
        self.height = TILE_SIZE
        
        self.image = self.game.terrain_spritesheet.get_sprite(960, 448, self.width, self.height)
        
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        

class Button:
    def __init__(self, x, y, width, height, fg, bg, content, fontsize):
        self.font = pygame.font.Font("arial.ttf", fontsize)
        self.content = content 
        
        self.x = x
        self.y = y
        self.width = width
        self.height = height
        
        self.fg = fg
        self.bg = bg
        
        self.image = pygame.Surface((self.width, self.height))
        self.image.fill(self.bg)
        self.rect = self.image.get_rect()
        
        self.rect.x = self.x
        self.rect.y = self.y
        
        self.text = self.font.render(self.content, True, self.fg)
        self.text_rect = self.text.get_rect(center=(self.width/2, self.height/2))
        self.image.blit(self.text, self.text_rect)
        
    def is_pressed(self, pos, pressed):
        if self.rect.collidepoint(pos):
            if pressed[0]:
                return True
            return False
        return False
        
        
class Spritesheet:
    def __init__(self, file):
        self.sheet = pygame.image.load(file).convert()
        
    def get_sprite(self, x, y, width, height):
        sprite = pygame.Surface([width, height])
        sprite.blit(self.sheet, (0, 0), (x, y, width, height))
        sprite.set_colorkey(BLACK)
        return sprite
        
        
class Sprites(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        
        self.x = x * TILE_SIZE
        self.y = y * TILE_SIZE
        self.width = TILE_SIZE
        self.height = TILE_SIZE
        self.image = self.game.terrain_spritesheet.get_sprite(3, 2, 32, 32)
        
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
       
        
    
class Guy(Sprites): #class in pygame module to make sprites
    def __init__(self, game, x, y):
        Sprites.__init__(self, game, x, y)
        self.groups = self.game.all_sprites #adding the player to all the sprites group, able to access because of passing game as an object
        pygame.sprite.Sprite.__init__(self, self.groups) #all the init method for the inherited class, adding player to all sprites group
        self.width = TILE_SIZE - 5 #minus 5 so player can go through the maze
        self.height = TILE_SIZE  - 5
        self.x_change = 0
        self.y_change = 0
        
        self.facing = 'down'
        
        self.index_holder = 0
        
        #sets the image for the guy
        self.image = self.game.character_spritesheet.get_sprite(3, 2, self.width, self.height)
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        self.move = False
        
    def collides(self, direction):
        hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
        hits_troll = pygame.sprite.spritecollide(self, self.game.trolls, False)
        hits_ghost = pygame.sprite.spritecollide(self, self.game.ghosts, False)
        hits_flag = pygame.sprite.spritecollide(self, self.game.flags, False)
        hits_fireball = pygame.sprite.spritecollide(self, self.game.fireballs, False)
        hits_mud = pygame.sprite.spritecollide(self, self.game.mud, False)
        hits_witch = pygame.sprite.spritecollide(self, self.game.witchs, False)
        hits_skeleton = pygame.sprite.spritecollide(self, self.game.skeleton, False)
        hits_alien = pygame.sprite.spritecollide(self, self.game.aliens, False)
        hits_blast = pygame.sprite.spritecollide(self, self.game.blasts, False)
        
        #tried
        # hits_powerup = pygame.sprite.spritecollide(self, self.game.powerup, False)
        
        if hits_troll or hits_fireball or hits_witch or hits_skeleton or hits_alien or hits_blast or hits_ghost:
            self.game.lose_life = True
                
        if hits_flag:
            self.game.new_level()
        '''
        if hits_powerup:
            pass
        '''    
        if hits_mud:
            self.game.guy_speed = 1
        
        else:
            self.game.guy_speed = 3
        
        if direction == 'x':
            if hits_wall:
                if self.x_change > 0:
                    self.rect.x = hits_wall[0].rect.left - self.rect.width
                    
                if self.x_change < 0:
                    self.rect.x = hits_wall[0].rect.right
         
        if direction == 'y':
            if hits_wall:
                if self.y_change > 0:
                    self.rect.y = hits_wall[0].rect.top - self.rect.height
                    
                if self.y_change < 0:
                    self.rect.y = hits_wall[0].rect.bottom
                    
    def update(self):
        self.movement()
        x_movement = self.rect.x
        y_movement = self.rect.y
        self.rect.x += self.x_change
        self.collides('x')
        self.rect.y += self.y_change
        self.collides('y')
        x_movement -= self.rect.x
        y_movement -= self.rect.y
        if x_movement == self.game.guy_speed:
            for sprite in self.game.all_sprites:
                sprite.rect.x += self.game.guy_speed
        
        if x_movement == -self.game.guy_speed:
            for sprite in self.game.all_sprites:
                sprite.rect.x -= self.game.guy_speed
                
        if y_movement == self.game.guy_speed:
            for sprite in self.game.all_sprites:
                sprite.rect.y += self.game.guy_speed
                
        if y_movement == -self.game.guy_speed:
            for sprite in self.game.all_sprites:
                sprite.rect.y -= self.game.guy_speed
        
        self.x_change = 0
        self.y_change = 0
        self.animate()
        
        if self.game.lives <= 0:
            self.game.lost = True
            self.game.intro_screen()
            self.game.new_game()
        
    def movement(self):
        keys = pygame.key.get_pressed()
        hits_ice = pygame.sprite.spritecollide(self, self.game.iceback, False)
        if hits_ice:
           self.x_change = 0
           self.x_change = 0
        else: 
            if keys[pygame.K_LEFT]:
                self.x_change -= self.game.guy_speed
                self.facing = 'left'
                
            if keys[pygame.K_RIGHT]:
                self.x_change += self.game.guy_speed
                self.facing = 'right'
                
            if keys[pygame.K_UP]:
                self.y_change -= self.game.guy_speed
                self.facing = 'up'
                
            if keys[pygame.K_DOWN]:
                self.y_change += self.game.guy_speed
                self.facing = 'down'
                
            else:
                self.x_change += 0.01
        
    def animate(self):
        hits_ice = pygame.sprite.spritecollide(self, self.game.iceback, False)
        if not hits_ice:
            keys = pygame.key.get_pressed()
            walk_down = [self.game.character_spritesheet.get_sprite(3, 2, self.width, self.height),
                               self.game.character_spritesheet.get_sprite(35, 2, self.width, self.height),
                               self.game.character_spritesheet.get_sprite(68, 2, self.width, self.height)]
                               
            walk_up = [self.game.character_spritesheet.get_sprite(3, 98, self.width, self.height),
                             self.game.character_spritesheet.get_sprite(35, 98, self.width, self.height),
                             self.game.character_spritesheet.get_sprite(68, 98, self.width, self.height)]

            walk_left = [self.game.character_spritesheet.get_sprite(3, 32, self.width, self.height),
                               self.game.character_spritesheet.get_sprite(35, 32, self.width, self.height),
                               self.game.character_spritesheet.get_sprite(68, 32, self.width, self.height)]

            walk_right = [self.game.character_spritesheet.get_sprite(3, 66, self.width, self.height),
                                self.game.character_spritesheet.get_sprite(35, 66, self.width, self.height),
                                self.game.character_spritesheet.get_sprite(68, 66, self.width, self.height)]
                                

            if self.facing == "left":
                if keys[pygame.K_LEFT]:
                    self.image = walk_left[int(self.index_holder)]
                    self.index_holder += 0.1
                    if self.index_holder >= 3:
                        self.index_holder = 0
                else:
                    self.game.character_spritesheet.get_sprite(3, 98, self.width, self.height)
            
            if self.facing == "right":
                if keys[pygame.K_RIGHT]:
                    self.image = walk_right[int(self.index_holder)]
                    self.index_holder += 0.1
                    if self.index_holder >= 3:
                        self.index_holder = 0
                else:
                    self.game.character_spritesheet.get_sprite(3, 66, self.width, self.height)
            
            if self.facing == "up":
                if keys[pygame.K_UP]:
                    self.image = walk_up[int(self.index_holder)]
                    self.index_holder += 0.1
                    if self.index_holder >= 3:
                        self.index_holder = 0
                else:
                    self.game.character_spritesheet.get_sprite(3, 98, self.width, self.height)
            
            if self.facing == "down":
                if keys[pygame.K_DOWN]:
                    self.image = walk_down[int(self.index_holder)]
                    self.index_holder += 0.1
                    if self.index_holder >= 3:
                        self.index_holder = 0
                else:
                    self.game.character_spritesheet.get_sprite(3, 2, self.width, self.height)
        
class Troll(Sprites):
    def __init__(self, game, x, y):
        Sprites.__init__(self, game, x, y)
        self._level = CHARACTER_LEVEL
        self.groups = self.game.all_sprites, self.game.trolls
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.x_change = 0
        self.y_change = 0
        self.index_holder = 0
        
        self.facing = choice(DIRECTIONS)  
        self.iterate = 0        
        
        self.image = self.game.enemy_spritesheet.get_sprite(3, 2, self.width, self.height)
        
    def collides(self, direction):
        pygame.sprite.spritecollide(self, self.game.attacks, True)
        if direction == 'x': #moving side to side
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)

                if self.x_change > 0:   # moving 
                    self.rect.x = hits_wall[0].rect.left - self.rect.width
                    
                if self.x_change < 0:
                    self.rect.x = hits_wall[0].rect.right
            
        if direction == 'y':  # moving up or down
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)
                if self.y_change > 0:
                    self.rect.y = hits_wall[0].rect.top - self.rect.height
                    
                if self.y_change < 0:
                    self.rect.y = hits_wall[0].rect.bottom  
    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collides('x')
        self.collides('y')    
        self.x_change = 0
        self.y_change = 0

    def movement(self):
        if self.facing == "up":
            self.y_change -= TROLL_VEL
            
        elif self.facing == "down":
            self.y_change += TROLL_VEL

        elif self.facing == "left":
            self.x_change -= TROLL_VEL
            
        elif self.facing == "right":
            self.x_change += TROLL_VEL
        
        else:
            self.facing = choice(DIRECTIONS)
            
    def animate(self):
        walk_down = [self.game.enemy_spritesheet.get_sprite(3, 2, self.width, self.height),
                           self.game.enemy_spritesheet.get_sprite(35, 2, self.width, self.height),
                           self.game.enemy_spritesheet.get_sprite(68, 2, self.width, self.height)]
                           
        walk_up = [self.game.enemy_spritesheet.get_sprite(3, 98, self.width, self.height),
                         self.game.enemy_spritesheet.get_sprite(35, 98, self.width, self.height),
                         self.game.enemy_spritesheet.get_sprite(68, 98, self.width, self.height)]

        walk_left = [self.game.enemy_spritesheet.get_sprite(3, 32, self.width, self.height),
                           self.game.enemy_spritesheet.get_sprite(35, 32, self.width, self.height),
                           self.game.enemy_spritesheet.get_sprite(68, 32, self.width, self.height)]

        walk_right = [self.game.enemy_spritesheet.get_sprite(3, 66, self.width, self.height),
                            self.game.enemy_spritesheet.get_sprite(35, 66, self.width, self.height),
                            self.game.enemy_spritesheet.get_sprite(68, 66, self.width, self.height)]
                            

        if self.facing == "left":
            self.image = walk_left[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "right":
            self.image = walk_right[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "up":
            self.image = walk_up[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "down":
            self.image = walk_down[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0


class Ghost(Sprites):
    def __init__(self, game, x, y):
        Sprites.__init__(self, game, x, y)
        self._level = CHARACTER_LEVEL
        self.groups = self.game.all_sprites, self.game.ghosts
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.x_change = 0
        self.y_change = 0
        self.count = 0
        self.facing = choice(DIRECTIONS)  
        self.iterate = 0        
        self.index_holder = 0
        self.image = self.game.ghosts_spritesheet.get_sprite(3, 2, self.width, self.height)
        
    def collides(self):
        if self.rect.x < 0:
            self.facing = "right"
            self.rect.x = 1
        
        if self.rect.y < 0:
            self.facing = "down"
            self.rect.y = 1
               
        if self.rect.x > WINDOW_WIDTH:
            self.facing = "left"
            self.rect.x = WINDOW_WIDTH - 1
            
        if self.rect.y > WINDOW_HEIGHT:
            self.facing = "up"
            self.rect.y = WINDOW_HEIGHT - 1
            
    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collides()
        self.x_change = 0
        self.y_change = 0

    def movement(self):
        if self.count < 60:
           self.count = self.count + 1          
        else:
            self.facing = choice(DIRECTIONS)
            self.count = 0

        if self.facing == "up":
            self.y_change -= GHOST_VEL
            
        elif self.facing == "down":
            self.y_change += GHOST_VEL

        elif self.facing == "left":
            self.x_change -= GHOST_VEL
            
        elif self.facing == "right":
            self.x_change += GHOST_VEL
        
        else:
            self.facing = choice(DIRECTIONS)
        
    def animate(self):
        walk_down = [self.game.ghosts_spritesheet.get_sprite(3, 2, self.width, self.height),
                           self.game.ghosts_spritesheet.get_sprite(35, 2, self.width, self.height),
                           self.game.ghosts_spritesheet.get_sprite(68, 2, self.width, self.height)]
                           
        walk_up = [self.game.ghosts_spritesheet.get_sprite(3, 98, self.width, self.height),
                         self.game.ghosts_spritesheet.get_sprite(35, 98, self.width, self.height),
                         self.game.ghosts_spritesheet.get_sprite(68, 98, self.width, self.height)]

        walk_left = [self.game.ghosts_spritesheet.get_sprite(3, 32, self.width, self.height),
                           self.game.ghosts_spritesheet.get_sprite(35, 32, self.width, self.height),
                           self.game.ghosts_spritesheet.get_sprite(68, 32, self.width, self.height)]

        walk_right = [self.game.ghosts_spritesheet.get_sprite(3, 66, self.width, self.height),
                            self.game.ghosts_spritesheet.get_sprite(35, 66, self.width, self.height),
                            self.game.ghosts_spritesheet.get_sprite(68, 66, self.width, self.height)]
                            

        if self.facing == "left":
            self.image = walk_left[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "right":
            self.image = walk_right[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "up":
            self.image = walk_up[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "down":
            self.image = walk_down[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0

class Alien(Sprites):
    def __init__(self, game, x, y):
        Sprites.__init__(self, game, x, y)
        self._level = CHARACTER_LEVEL
        self.groups = self.game.all_sprites, self.game.aliens
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.x_change = 0
        self.y_change = 0
        self.index_holder = 0
        
        self.facing = choice(DIRECTIONS)  
        self.iterate = 0        
        
        self.image = self.game.aliens_spritesheet.get_sprite(3, 2, self.width, self.height)
        
    def collides(self, direction):
        pygame.sprite.spritecollide(self, self.game.attacks, True)
        if direction == 'x': #moving side to side
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)

                if self.x_change > 0:   # moving 
                    self.rect.x = hits_wall[0].rect.left - self.rect.width
                    
                if self.x_change < 0:
                    self.rect.x = hits_wall[0].rect.right
            
        if direction == 'y':  # moving up or down
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)
                if self.y_change > 0:
                    self.rect.y = hits_wall[0].rect.top - self.rect.height
                    
                if self.y_change < 0:
                    self.rect.y = hits_wall[0].rect.bottom  
    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collides('x')
        self.collides('y')    
        self.x_change = 0
        self.y_change = 0

    def movement(self):
        if self.facing == "up":
            self.y_change -= WITCH_VEL
            
        elif self.facing == "down":
            self.y_change += WITCH_VEL

        elif self.facing == "left":
            self.x_change -= WITCH_VEL
            
        elif self.facing == "right":
            self.x_change += WITCH_VEL
        
        else:
            self.facing = choice(DIRECTIONS)
     
    def animate(self):
        walk_down = [self.game.aliens_spritesheet.get_sprite(3, 2, self.width, self.height),
                           self.game.aliens_spritesheet.get_sprite(35, 2, self.width, self.height),
                           self.game.aliens_spritesheet.get_sprite(68, 2, self.width, self.height)]
                           
        walk_up = [self.game.aliens_spritesheet.get_sprite(3, 98, self.width, self.height),
                         self.game.aliens_spritesheet.get_sprite(35, 98, self.width, self.height),
                         self.game.aliens_spritesheet.get_sprite(68, 98, self.width, self.height)]

        walk_left = [self.game.aliens_spritesheet.get_sprite(3, 32, self.width, self.height),
                           self.game.aliens_spritesheet.get_sprite(35, 32, self.width, self.height),
                           self.game.aliens_spritesheet.get_sprite(68, 32, self.width, self.height)]

        walk_right = [self.game.aliens_spritesheet.get_sprite(3, 66, self.width, self.height),
                            self.game.aliens_spritesheet.get_sprite(35, 66, self.width, self.height),
                            self.game.aliens_spritesheet.get_sprite(68, 66, self.width, self.height)]
                            

        if self.facing == "left":
            self.image = walk_left[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "right":
            self.image = walk_right[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "up":
            self.image = walk_up[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "down":
            self.image = walk_down[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0

class IceGuy(Sprites):
    def __init__(self, game, x, y):
        Sprites.__init__(self, game, x, y)
        self._level = CHARACTER_LEVEL
        self.groups = self.game.all_sprites, self.game.ice
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.index_holder = 0
        self.x_change = 0
        self.y_change = 0
        self.count = 0
        self.duration = 0
        self.move = True
        
        self.facing = choice(DIRECTIONS)  
        self.iterate = 0        
        
        self.image = self.game.ice_spritesheet.get_sprite(3, 2, self.width, self.height)
        
    def collides(self, direction):
        if direction == 'x': #moving side to side
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)

                if self.x_change > 0:   # moving 
                    self.rect.x = hits_wall[0].rect.left - self.rect.width
                    
                if self.x_change < 0:
                    self.rect.x = hits_wall[0].rect.right
            
        if direction == 'y':  # moving up or down
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)
                if self.y_change > 0:
                    self.rect.y = hits_wall[0].rect.top - self.rect.height
                    
                if self.y_change < 0:
                    self.rect.y = hits_wall[0].rect.bottom  
    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collides('x')
        self.collides('y')    
        self.x_change = 0
        self.y_change = 0

    def movement(self):
        hits_ice = pygame.sprite.spritecollide(self, self.game.iceback, False)
        if hits_ice:
            self.y_change = 0
            self.x_change = 0
        else:
            if self.facing == "up":
                self.y_change -= TROLL_VEL
                
            elif self.facing == "down":
                self.y_change += TROLL_VEL

            elif self.facing == "left":
                self.x_change -= TROLL_VEL
                
            elif self.facing == "right":
                self.x_change += TROLL_VEL
            
            else:
                self.facing = choice(DIRECTIONS)
    
    def animate(self):
        hits_ice = pygame.sprite.spritecollide(self, self.game.iceback, False)
        if not hits_ice:
            walk_down = [self.game.ice_spritesheet.get_sprite(3, 2, self.width, self.height),
                               self.game.ice_spritesheet.get_sprite(35, 2, self.width, self.height),
                               self.game.ice_spritesheet.get_sprite(68, 2, self.width, self.height)]
                               
            walk_up = [self.game.ice_spritesheet.get_sprite(3, 98, self.width, self.height),
                             self.game.ice_spritesheet.get_sprite(35, 98, self.width, self.height),
                             self.game.ice_spritesheet.get_sprite(68, 98, self.width, self.height)]

            walk_left = [self.game.ice_spritesheet.get_sprite(3, 32, self.width, self.height),
                               self.game.ice_spritesheet.get_sprite(35, 32, self.width, self.height),
                               self.game.ice_spritesheet.get_sprite(68, 32, self.width, self.height)]

            walk_right = [self.game.ice_spritesheet.get_sprite(3, 66, self.width, self.height),
                                self.game.ice_spritesheet.get_sprite(35, 66, self.width, self.height),
                                self.game.ice_spritesheet.get_sprite(68, 66, self.width, self.height)]
                                

            if self.facing == "left":
                self.image = walk_left[int(self.index_holder)]
                self.index_holder += 0.1
                if self.index_holder >= 3:
                    self.index_holder = 0
            
            if self.facing == "right":
                self.image = walk_right[int(self.index_holder)]
                self.index_holder += 0.1
                if self.index_holder >= 3:
                    self.index_holder = 0
            
            if self.facing == "up":
                self.image = walk_up[int(self.index_holder)]
                self.index_holder += 0.1
                if self.index_holder >= 3:
                    self.index_holder = 0
            
            if self.facing == "down":
                self.image = walk_down[int(self.index_holder)]
                self.index_holder += 0.1
                if self.index_holder >= 3:
                    self.index_holder = 0
        
class Witch(Sprites):
    def __init__(self, game, x, y):
        Sprites.__init__(self, game, x, y)
        self._level = CHARACTER_LEVEL
        self.groups = self.game.all_sprites, self.game.witchs
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.x_change = 0
        self.y_change = 0
        self.index_holder = 0
        
        self.facing = choice(DIRECTIONS)  
        self.iterate = 0        
        
        self.image = self.game.witchs_spritesheet.get_sprite(3, 2, self.width, self.height)
        
    def collides(self, direction):
        pygame.sprite.spritecollide(self, self.game.attacks, True)
        if direction == 'x': #moving side to side
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)

                if self.x_change > 0:   # moving 
                    self.rect.x = hits_wall[0].rect.left - self.rect.width
                    
                if self.x_change < 0:
                    self.rect.x = hits_wall[0].rect.right
            
        if direction == 'y':  # moving up or down
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)
                if self.y_change > 0:
                    self.rect.y = hits_wall[0].rect.top - self.rect.height
                    
                if self.y_change < 0:
                    self.rect.y = hits_wall[0].rect.bottom  
    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collides('x')
        self.collides('y')    
        self.x_change = 0
        self.y_change = 0

    def movement(self):
        if self.facing == "up":
            self.y_change -= WITCH_VEL
            
        elif self.facing == "down":
            self.y_change += WITCH_VEL

        elif self.facing == "left":
            self.x_change -= WITCH_VEL
            
        elif self.facing == "right":
            self.x_change += WITCH_VEL
        
        else:
            self.facing = choice(DIRECTIONS)
     
    def animate(self):
        walk_down = [self.game.witchs_spritesheet.get_sprite(3, 2, self.width, self.height),
                           self.game.witchs_spritesheet.get_sprite(35, 2, self.width, self.height),
                           self.game.witchs_spritesheet.get_sprite(68, 2, self.width, self.height)]
                           
        walk_up = [self.game.witchs_spritesheet.get_sprite(3, 98, self.width, self.height),
                         self.game.witchs_spritesheet.get_sprite(35, 98, self.width, self.height),
                         self.game.witchs_spritesheet.get_sprite(68, 98, self.width, self.height)]

        walk_left = [self.game.witchs_spritesheet.get_sprite(3, 32, self.width, self.height),
                           self.game.witchs_spritesheet.get_sprite(35, 32, self.width, self.height),
                           self.game.witchs_spritesheet.get_sprite(68, 32, self.width, self.height)]

        walk_right = [self.game.witchs_spritesheet.get_sprite(3, 66, self.width, self.height),
                            self.game.witchs_spritesheet.get_sprite(35, 66, self.width, self.height),
                            self.game.witchs_spritesheet.get_sprite(68, 66, self.width, self.height)]
                            

        if self.facing == "left":
            self.image = walk_left[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "right":
            self.image = walk_right[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "up":
            self.image = walk_up[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "down":
            self.image = walk_down[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0

class Skeleton(pygame.sprite.Sprite):
    def __init__(self, game, x, y, facing):
        self.game = game
        self.groups = self.game.all_sprites, self.game.skeleton
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.speed = 0.1
        self.x = x
        self.y = y
        self.width = TILE_SIZE
        self.height = TILE_SIZE
        
        self.facing = facing
        
        self.x_change = 0
        self.y_change = 0  
        self.index_holder = 0
        
        self.image = self.game.skeleton_spritesheet.get_sprite(3, 2, self.width, self.height)
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
        
    def collides(self, direction):
        pygame.sprite.spritecollide(self, self.game.attacks, True)
        if direction == 'x': #moving side to side
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)

                if self.x_change > 0:   # moving 
                    self.rect.x = hits_wall[0].rect.left - self.rect.width
                    
                if self.x_change < 0:
                    self.rect.x = hits_wall[0].rect.right
            
        if direction == 'y':  # moving up or down
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)
                if self.y_change > 0:
                    self.rect.y = hits_wall[0].rect.top - self.rect.height
                    
                if self.y_change < 0:
                    self.rect.y = hits_wall[0].rect.bottom  
    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collides('x')
        self.collides('y')    
        self.x_change = 0
        self.y_change = 0

    def movement(self):
        if self.facing == "up":
            self.y_change -= SKELETON_VEL
            
        elif self.facing == "down":
            self.y_change += SKELETON_VEL

        elif self.facing == "left":
            self.x_change -= SKELETON_VEL
            
        elif self.facing == "right":
            self.x_change += SKELETON_VEL
        
        else:
            self.facing = choice(DIRECTIONS)
     
    def animate(self):
        walk_down = [self.game.skeleton_spritesheet.get_sprite(3, 2, self.width, self.height),
                           self.game.skeleton_spritesheet.get_sprite(35, 2, self.width, self.height),
                           self.game.skeleton_spritesheet.get_sprite(68, 2, self.width, self.height)]
                           
        walk_up = [self.game.skeleton_spritesheet.get_sprite(3, 98, self.width, self.height),
                         self.game.skeleton_spritesheet.get_sprite(35, 98, self.width, self.height),
                         self.game.skeleton_spritesheet.get_sprite(68, 98, self.width, self.height)]

        walk_left = [self.game.skeleton_spritesheet.get_sprite(3, 32, self.width, self.height),
                           self.game.skeleton_spritesheet.get_sprite(35, 32, self.width, self.height),
                           self.game.skeleton_spritesheet.get_sprite(68, 32, self.width, self.height)]

        walk_right = [self.game.skeleton_spritesheet.get_sprite(3, 66, self.width, self.height),
                            self.game.skeleton_spritesheet.get_sprite(35, 66, self.width, self.height),
                            self.game.skeleton_spritesheet.get_sprite(68, 66, self.width, self.height)]
                            

        if self.facing == "left":
            self.image = walk_left[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "right":
            self.image = walk_right[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "up":
            self.image = walk_up[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "down":
            self.image = walk_down[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
class Boss(Sprites):
    def __init__(self, game, x, y):
        Sprites.__init__(self, game, x, y)
        self._level = CHARACTER_LEVEL
        self.groups = self.game.all_sprites, self.game.boss
        pygame.sprite.Sprite.__init__(self, self.groups)
        self.x = x
        self.y = x
        self.width = TILE_SIZE * 2
        self.height = TILE_SIZE * 2
        
        self.lives = 5
        self.x_change = 0
        self.y_change = 0
        self.count = 0
        self.facing = choice(DIRECTIONS)  
        self.iterate = 0        
        self.index_holder = 0
        self.image = self.game.boss_spritesheet.get_sprite(3, 2, self.width, self.height)
        
    def collides(self):
        if self.rect.x < 0:
            self.facing = "right"
            self.rect.x = 1
        
        if self.rect.y < 0:
            self.facing = "down"
            self.rect.y = 1
               
        if self.rect.x > WINDOW_WIDTH:
            self.facing = "left"
            self.rect.x = WINDOW_WIDTH - 1
            
        if self.rect.y > WINDOW_HEIGHT:
            self.facing = "up"
            self.rect.y = WINDOW_HEIGHT - 1
        
        hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
        if hits_wall:
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, True)
        
        hits_attack = pygame.sprite.spritecollide(self, self.game.attacks, False)
        if hits_attack:
           hits_attack = pygame.sprite.spritecollide(self, self.game.attacks, True)
           self.lives = self.lives - 1
           print("{} lives left".format(str(self.lives)))
           if self.lives == 0:
                pygame.sprite.spritecollide(self, self.game.boss, True)
        
        
            
    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collides()
        self.x_change = 0
        self.y_change = 0

    def movement(self):
        if self.count < 60:
           self.count = self.count + 1          
        else:
            self.facing = choice(DIRECTIONS)
            self.count = 0

        if self.facing == "up":
            self.y_change -= GHOST_VEL
            
        elif self.facing == "down":
            self.y_change += GHOST_VEL

        elif self.facing == "left":
            self.x_change -= GHOST_VEL
            
        elif self.facing == "right":
            self.x_change += GHOST_VEL
        
        else:
            self.facing = choice(DIRECTIONS)
        
    def animate(self):
        walk_down = [self.game.boss_spritesheet.get_sprite(6, 0, self.width, self.height),
                           self.game.boss_spritesheet.get_sprite(70, 0, self.width, self.height),
                           self.game.boss_spritesheet.get_sprite(134, 0, self.width, self.height)]
                           
        walk_up = [self.game.boss_spritesheet.get_sprite(6, 196, self.width, self.height),
                         self.game.boss_spritesheet.get_sprite(70, 196, self.width, self.height),
                         self.game.boss_spritesheet.get_sprite(134, 196, self.width, self.height)]

        walk_left = [self.game.boss_spritesheet.get_sprite(6, 68, self.width, self.height),
                           self.game.boss_spritesheet.get_sprite(70, 68, self.width, self.height),
                           self.game.boss_spritesheet.get_sprite(134, 68, self.width, self.height)]

        walk_right = [self.game.boss_spritesheet.get_sprite(6, 132, self.width, self.height),
                            self.game.boss_spritesheet.get_sprite(70, 132, self.width, self.height),
                            self.game.boss_spritesheet.get_sprite(134, 132, self.width, self.height)]
                            

        if self.facing == "left":
            self.image = walk_left[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "right":
            self.image = walk_right[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "up":
            self.image = walk_up[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "down":
            self.image = walk_down[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
                
class Minion(pygame.sprite.Sprite):
    def __init__(self, game, x, y, facing):
        self.game = game
        self.groups = self.game.all_sprites, self.game.minion
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.speed = 0.1
        self.x = x
        self.y = y
        self.width = TILE_SIZE
        self.height = TILE_SIZE
        
        self.facing = facing
        
        self.x_change = 0
        self.y_change = 0  
        self.index_holder = 0
        
        self.image = self.game.minion_spritesheet.get_sprite(3, 2, self.width, self.height)
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
        
    def collides(self, direction):
        pygame.sprite.spritecollide(self, self.game.attacks, True)
        if direction == 'x': #moving side to side
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)

                if self.x_change > 0:   # moving 
                    self.rect.x = hits_wall[0].rect.left - self.rect.width
                    
                if self.x_change < 0:
                    self.rect.x = hits_wall[0].rect.right
            
        if direction == 'y':  # moving up or down
            hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
            if hits_wall:
                self.facing = choice(DIRECTIONS)
                if self.y_change > 0:
                    self.rect.y = hits_wall[0].rect.top - self.rect.height
                    
                if self.y_change < 0:
                    self.rect.y = hits_wall[0].rect.bottom  
    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collides('x')
        self.collides('y')    
        self.x_change = 0
        self.y_change = 0

    def movement(self):
        if self.facing == "up":
            self.y_change -= SKELETON_VEL
            
        elif self.facing == "down":
            self.y_change += SKELETON_VEL

        elif self.facing == "left":
            self.x_change -= SKELETON_VEL
            
        elif self.facing == "right":
            self.x_change += SKELETON_VEL
        
        else:
            self.facing = choice(DIRECTIONS)
     
    def animate(self):
        walk_down = [self.game.minion_spritesheet.get_sprite(3, 2, self.width, self.height),
                           self.game.minion_spritesheet.get_sprite(35, 2, self.width, self.height),
                           self.game.minion_spritesheet.get_sprite(68, 2, self.width, self.height)]
                           
        walk_up = [self.game.minion_spritesheet.get_sprite(3, 98, self.width, self.height),
                         self.game.minion_spritesheet.get_sprite(35, 98, self.width, self.height),
                         self.game.minion_spritesheet.get_sprite(68, 98, self.width, self.height)]

        walk_left = [self.game.minion_spritesheet.get_sprite(3, 32, self.width, self.height),
                           self.game.minion_spritesheet.get_sprite(35, 32, self.width, self.height),
                           self.game.minion_spritesheet.get_sprite(68, 32, self.width, self.height)]

        walk_right = [self.game.minion_spritesheet.get_sprite(3, 66, self.width, self.height),
                            self.game.minion_spritesheet.get_sprite(35, 66, self.width, self.height),
                            self.game.minion_spritesheet.get_sprite(68, 66, self.width, self.height)]
                            

        if self.facing == "left":
            self.image = walk_left[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "right":
            self.image = walk_right[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "up":
            self.image = walk_up[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0
        
        if self.facing == "down":
            self.image = walk_down[int(self.index_holder)]
            self.index_holder += 0.1
            if self.index_holder >= 3:
                self.index_holder = 0       

class Attack(pygame.sprite.Sprite):
    def __init__(self, game, x, y, facing):
        self.game = game
        self.groups = self.game.all_sprites, self.game.attacks
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.speed = 0.1
        self.x = x
        self.y = y
        self.width = FIRE_BALL_TILE
        self.height = FIRE_BALL_TILE
        
        self.x_change = 0
        self.y_change = 0
        self.index_holder = 0
        
        self.facing = facing

        self.image = self.game.attack_spritesheet.get_sprite(0,0,self.width, self.height)
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        self.count = 0
        
    def movement(self):
            
        if self.facing == "up":
            self.y_change -= self.speed
            
        elif self.facing == "down":
            self.y_change += self.speed

        elif self.facing == "left":
            self.x_change -= self.speed
            
        elif self.facing == "right":
            self.x_change += self.speed
        
        else:
            self.x_change += 0.01

    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collide()
   
    def collide(self):
        hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
        
        hits_troll = pygame.sprite.spritecollide(self, self.game.trolls, True)
        hits_fireball = pygame.sprite.spritecollide(self, self.game.fireballs, True)
        hits_skeleton = pygame.sprite.spritecollide(self, self.game.skeleton, True)
        hits_ghosts = pygame.sprite.spritecollide(self, self.game.ghosts, True)
        hits_witchs = pygame.sprite.spritecollide(self, self.game.witchs, True)
        hits_aliens = pygame.sprite.spritecollide(self, self.game.aliens, True)
        hits_ice = pygame.sprite.spritecollide(self, self.game.ice, True)
        hits_minion = pygame.sprite.spritecollide(self, self.game.minion, True)
        
        if hits_wall or hits_troll or hits_fireball or hits_skeleton or hits_ghosts or hits_witchs or hits_aliens or hits_ice or hits_minion:
            pygame.sprite.spritecollide(self, self.game.attacks, True)
        
    
    def animate(self):
        moving = [pygame.image.load('img/attack1.png'),pygame.image.load('img/attack2.png'),pygame.image.load('img/attack3.png'),pygame.image.load('img/attack4.png')]

        self.image = moving[int(self.index_holder)]
        self.index_holder += 0.1
        if self.index_holder >= 4:
            self.index_holder = 0

class Blast(pygame.sprite.Sprite):
    def __init__(self, game, x, y, facing):
        self.game = game
        self.groups = self.game.all_sprites, self.game.blasts
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.speed = 0.1
        self.x = x
        self.y = y
        self.width = FIRE_BALL_TILE
        self.height = FIRE_BALL_TILE
        
        self.index_holder = 0
        self.x_change = 0
        self.y_change = 0
        self.count = 0
        
        self.facing = facing

        self.image = self.game.blasts_spritesheet.get_sprite(0,0,self.width, self.height)
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
    def movement(self):
            
        if self.facing == "up":
            self.y_change -= self.speed
            
        elif self.facing == "down":
            self.y_change += self.speed

        elif self.facing == "left":
            self.x_change -= self.speed
            
        elif self.facing == "right":
            self.x_change += self.speed
        
        else:
            self.x_change += 0.01
        
        
        if self.count < 30:
            self.count = self.count + 1
        else:
            delete = pygame.sprite.spritecollide(self, self.game.blasts, True)
            self.count = 0



    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collide()
   
    def collide(self):
        pygame.sprite.spritecollide(self, self.game.attacks, True)
    
    def animate(self):
        moving = [self.game.blasts_spritesheet.get_sprite(0,0,self.width, self.height), self.game.blasts2_spritesheet.get_sprite(0,0,self.width, self.height), self.game.blasts3_spritesheet.get_sprite(0,0,self.width, self.height), self.game.blasts4_spritesheet.get_sprite(0,0,self.width, self.height)]

        self.image = moving[int(self.index_holder)]
        self.index_holder += 0.1
        if self.index_holder >= 4:
            self.index_holder = 0

class Fireball(pygame.sprite.Sprite):
    def __init__(self, game, x, y, facing):
        self.game = game
        self.groups = self.game.all_sprites, self.game.fireballs
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.speed = 0.05
        self.x = x
        self.y = y
        self.width = FIRE_BALL_TILE
        self.height = FIRE_BALL_TILE
        
        self.x_change = 0
        self.y_change = 0
        self.index_holder = 0
        
        if facing == "left":
            self.facing = "right"
            
        if facing == "right":
            self.facing = "left"
            
        if facing == "up":
            self.facing = "down"
            
        if facing == "down":
            self.facing = "up"
        
        self.image = self.game.attack_spritesheet.get_sprite(0,0,self.width, self.height)
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
    def movement(self):
            
        if self.facing == "up":
            self.y_change -= self.speed
            
        elif self.facing == "down":
            self.y_change += self.speed

        elif self.facing == "left":
            self.x_change -= self.speed
            
        elif self.facing == "right":
            self.x_change += self.speed
        
        else:
            self.x_change += 0.01


    def update(self):
        self.movement()
        self.animate()
        self.rect.x += self.x_change
        self.rect.y += self.y_change
        self.collide()
   
    def collide(self):
        pygame.sprite.spritecollide(self, self.game.attacks, True)
        hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
        if hits_wall:
            delete = pygame.sprite.spritecollide(self, self.game.fireballs, True) 
    
    def animate(self):
        moving = [pygame.image.load('img/attack1.png'),pygame.image.load('img/attack2.png'),pygame.image.load('img/attack3.png'),pygame.image.load('img/attack4.png')]

        self.image = moving[int(self.index_holder)]
        self.index_holder += 0.1
        if self.index_holder >= 4:
            self.index_holder = 0

class Ice(pygame.sprite.Sprite):
    def __init__(self, game, x, y, facing):
        self.game = game
        self._level = CHARACTER_LEVEL
        self.groups = self.game.all_sprites, self.game.iceback
        pygame.sprite.Sprite.__init__(self, self.groups)
        self.count = 0
        self.x = x
        self.y = y
        self.width = 130
        self.height = 130
        
        if facing == "left":
            self.facing = "right"
            
        if facing == "right":
            self.facing = "left"
            
        if facing == "up":
            self.facing = "down"
            
        if facing == "down":
            self.facing = "up"
        
        self.image = pygame.image.load('img/icebackground2.png')
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
        
    def movement(self):
       if self.count < 120:
            self.count = self.count + 1
       else:
            delete = pygame.sprite.spritecollide(self, self.game.iceback, True)
            self.count = 0


    def update(self):
        self.collide()
        self.movement()
   
    def collide(self):
        hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
        pygame.sprite.spritecollide(self, self.game.attacks, True)
        if hits_wall:
            delete = pygame.sprite.spritecollide(self, self.game.fireballs, False)
    
    def animate(self):
        pass


class PowerUp(pygame.sprite.Sprite):
    def __init__(self, game, x, y):
        self.game = game
        self._layer = CHARACTER_LEVEL
        self.groups = self.game.all_sprites, self.game.powerup
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.x = x * TILE_SIZE
        self.y = y * TILE_SIZE
        self.width = TILE_SIZE
        self.height = TILE_SIZE
        
        self.image = self.game.attack_spritesheet.get_sprite(0,0,self.width, self.height)
        self.rect = self.image.get_rect()
        self.rect.x = self.x
        self.rect.y = self.y
    
    def update(self):
        self.collide()
   
    def collide(self):
        #hits = pygame.sprite.spritecollide(self, self.game.trolls, True)
        hits_wall = pygame.sprite.spritecollide(self, self.game.walls, False)
       
        
class Floor(Sprites):
    def __init__(self, game, x, y, num, num2):
        Sprites.__init__(self, game, x, y)
        self.groups = self.game.all_sprites
        pygame.sprite.Sprite.__init__(self, self.groups)
        self.image = self.game.terrain_spritesheet.get_sprite(num, num2, self.width, self.height)
       
       
class Wall(Sprites):
    def __init__(self, game, x, y, num, num2):
        Sprites.__init__(self, game, x, y)
        self.groups = self.game.all_sprites, self.game.walls
        pygame.sprite.Sprite.__init__(self, self.groups)
        
        self.image = self.game.terrain_spritesheet.get_sprite(num, num2, self.width, self.height)
     
        
class Flag(Sprites):
    def __init__(self, game, x, y):
        Sprites.__init__(self, game, x, y)
        
        self.image = self.game.flag_spritesheet.get_sprite(0, 0, self.width, self.height)
        self.groups = self.game.all_sprites, self.game.flags
        pygame.sprite.Sprite.__init__(self, self.groups)
       
       
class Mud(Sprites):
    def __init__(self, game, x, y):
        Sprites.__init__(self, game, x, y)
        self.image = self.game.terrain_spritesheet.get_sprite(0, 0, self.width, self.height)
        self.groups = self.game.all_sprites, self.game.mud
        pygame.sprite.Sprite.__init__(self, self.groups)